function MEG_audiovisual_BrandmanEtAl2019
%
%%% T Brandman, C Avancini, O Leticevscaia, MV Peelen, 2019 (MEG audiovisual facilitation study)
%
%%% MEG data analysis: Preprocessing (Fieldtrip), multivariate analysis using LDA classifier (CosmoMVPA) 
%   and significance testing using TFCE clustering (CosmoMVPA).
%
% This code requires that visual onsets are marked by MEG trigger values
% corresponding to individual exemplars. 
%
%%% Testing on "clear sounds" requires an indexing mat file stimIndex.mat 
%   (see example included in code folder) marking included/excluded trigger
%   values for each participant group (stimulus subset), as well as an
%   indexing mat file subjects.mat assigning participants to their
%   corresponding stimulus subset.
%
%%% Before running, organize project folders as follows:
%   1. Root project directory - set path in ProjectRootDir
%   2. Under root, create 3 folders: data; scripts - with contents of code folder; results.
%   3. Under data create 2 folders: raw - with raw fif files; maxfiltered - with max-filtered fif files (if relevant
%   4. File naming for raw fif files: '[subjectID(referred to by subjects.mat)]...[runID(referred to by runsuffix)].fif'
%       e.g. 'subject01_exampleExperiment_Main1.fif'
%   5. File naming for max-filtered fif files: '[subjectID(referred to by subjects.mat)]...[runID(referred to by runsuffix)]_tsss_trans.fif'
%       e.g. 'subject01_exampleExperiment_Main1_tsss_trans.fif'
%
%%% example files included in code folder: 
%   - subjects matrix: subjects.mat
%   - stimulus inclusion index, by trigger value: stimIndex.mat (inclusion/exclusion marked 1 or 0 in columns pointed to by stimIndexColumns)
%   - time-by-time mask: sampleMask.mat
% 
%%% IMPORTANT NOTE: Before beginning job 1, data were filtered using Elekta MaxFilter 
%   (including spatial realignment) on CIMeC MEG servers. See wiki page: 
%   https://wiki.cimec.unitn.it/tiki-index.php?page=Cleaning%20and%20realigning%20data%20using%20MaxFilter
%
%%% Inquiries should be addressed to talli.unitn@gmail.com
%
% Fieldtrip toolbox: http://www.fieldtriptoolbox.org/
% CosmoMVPA toolbox: http://cosmomvpa.org/

%% sample plot commands (for phase 3 results)
% %%% plot timeXtime accuracy matrix (insert relevant condition in accuracy_all {1,x})
% figure; imagesc(accuracy_all{1,1},[0.4 0.6]);
% colorbar;
% axis xy;
% colormap jet;
% h = gca;
% h.XTickLabel = {'100', '200', '300', '400','500','600'};
% h.YTickLabel = {'100', '200', '300', '400','500','600'};

%% settings

job = 1; % what stage of analysis to run:
%       1 - read epochs and perform filtering - requires Fieldtrip
%       2 - prepare trial datasets for MVPA - requires CosmoMVPA
%       3 - timeXtime MVPA using Cosmo across paired-conditions - requires CosmoMVPA
%       4 - group significance test of timeXtime maps - requires CosmoMVPA

% paths
ProjectRootDir = '/Volumes/TalliStrg/Talli_Analysis_ongoing/OtherProjects/AudioVisual';
FTdir = '/Volumes/TalliStrg/Talli_Analysis_ongoing/MATLAB/fieldtrip-20160316'; % path to FieldTrip toolbox folder
cosmopath = '/Volumes/TalliStrg/Talli_Analysis_ongoing/MATLAB/CoSMoMVPA-master_Nov2017/mvpa'; % path to cosmo toolbox functions
bioinfo = '/Volumes/TalliStrg/Talli_Analysis_ongoing/MATLAB/bioinfo'; % path to bioinfo toolbox functions (if not already saved in your matlab paths)  

% general settings
maxfilter = true; % if true, will load max-filtered fif files instead of raw.
runsuffix = [{'Main1'},{'Main2'},{'Main3'},{'Main4'},{'Main5'},{'Main6'},... % array of runs to analyze by suffix of fif file
    {'Loc1'},{'Loc2'}];  % e.g. fif file of localizer run #1 of subject01 would be named 'subject01...Loc1.fif'
suffixString = 'demean_detrend_maxfilter'; % suffix for trials filename

%%% phase 1 settings: Epoch and preprocessing definitions
eventTypeLabel = 'STI101'; % event type label - what type of triggers to refer to (depends on MEG online trigger labeling)
prestim = 0.2; % how long before trigger to include in secs
poststim = 0.8; % how long after triger to include in secs
lastTrigVal = 254; % value of last MEG trigger to load (if relevant, to avoid loading redundant data)
isLoPass = false; % whether to use low pass filter
isHiPass = false; % whether to use high pass filter
isPadding = false; % whether to use padding

%%% phase 2 settings: experimental conditions and MVPA prep
loc = [7:8]; % run numbers of pattern localizer
main = [1:6]; % run numbers of main experiment
opt.detrend = 'yes';
opt.demean = 'yes';
data_samplerate=100; %Sample rate for decoding
% structures of condition identifiers for main experiment and pattern localizer
% condsLoc: For localizer (intact objects), defines the MEG triggers corresponding to visual onsets, to include for each condition.
condsLoc = struct('title',{'intactAnimOld','intactInanimOld','intactAnimNew','intactInanimNew'},... % condition names for training
    'from',{1,43,85,127},...% trigger identifiers for each condition start from
    'to',{42,84,126,168}); % trigger identifiers for each condition end at
% condsMain: For main experiments, defines the MEG triggers corresponding to visual onsets, to include for each condition.
%   condition labeling: % Va/Vi/V0 - visual animat/inanimate/gray-rectangle , 
%   Wa/Wi - word animate/inanimate, Sa/Si - sound animate/inanimate, N - noise. 
condsMain = struct('title',{'VaWa','ViWi','VaSa','ViSi','VaN','ViN','V0Sa','V0Si'},...
    'from',{1,15,29,43,57,71,157,171},...% trigger identifiers for each condition start from
    'to',{14,28,42,56,70,84,170,184}); % trigger identifiers for each condition end at

%%% phase 3 settings: MVPA
resString = 'withAveraging2_smoothedTime2nb_onlyMMchn_onlyPOSTchn';%MMchAndCombGMch_allHead_Nbrhd25_SLmaskSoundP05'; % suffix to name results file
includeTimepoints = [21:80]; % according to prestim, poststim and data_samplerate, e.g. for 0.4-1.5, 100hz, timepoints 21:180 are -200 ms to 1400 ms
mvopt.d_channels=1; %0: all channels; 1: magnetometers; 2: gradiometers; 
mvopt.ap_channels = 2; % 0: all channels; 1: anterior; 2: posterior
mvopt.trainOn = 'loc'; % what data to train on: 'loc' for localizer, 'main' for main experiment
mvopt.testOn = 'main'; % what data to test on: 'loc' for localizer, 'main' for main experiment
mvopt.numNeighbAvg= 2; % number of neighbours (on each side) to include in temporal signal smoothing (pre-classification) e.g. for samplerate 100, 1 timepoint= 10 ms
mvopt.numNeighbSmooth = 2; % DIAGONAL ONLY - number of neighbours to include in timeXtime smoothing of results (post classification) e.g. for samplerate 100, 1 timepoint= 10 ms
% structure with condition pairs to classify:
%   number IDs corresponding to condition order in condsMain and condsLoc
% condPairs = struct('names',{'intactObj'},'class1train',{[1]},... %%% when training and testing on intact-objects (localizer)
%     'class2train',{[2]},'class1test',{[3]},'class2test',{[4]});    
condPairs = struct('names',{'objWithWord','objWithSound','objWithNoise','objWith62ClearSounds','grayWithSound'},... % cross-decoding (localizer -> main experiment)
    'class1train',{[1,3],[1,3],[1,3],[1,3],[1,3]},...
    'class2train',{[2,4],[2,4],[2,4],[2,4],[2,4]},...
    'class1test',{1,3,5,3,7},...
    'class2test',{2,4,6,4,8});                   
% in case testing on specific stimuli - "clear sounds" condition:
testOnSpecificExemplars = true; % if true, will test classifier predictions only on predefined trigger values from stimIndex.mat (but training on all)
withinWhichCondPair = 4; % condition for sample pruning referring to order by condPairs (e.g. if 2, then when classifying condPairs(2), will test predictions only on samples defined by stimIndex)
stimIndexColumns = {[],[],[],[3,5,7],[]}; % For each CondPair, which columns in stimIndex.mat refer to subject groups 1,2,3 respectively. (First stimIndex column MUST be trigger value).
 
%%% phase 4 settings: group significance testing
testopt.maskWithTimeROI = true; % if true mask with a timeXtime ROI (only timepoints with value 1 will be included).
% testopt.TimeROIfilename: filename of mask mat file (see example in code folder), to be saved in "results" folder,
%   includes the variable accuracy_all{1,1} - a cell array with a single entry, within it a mask
%   corresponding to the time-by-time matrix with 1 for included timepoints and 0 for excluded. 
testopt.TimeROIfilename = 'sampleMask.mat';
% testopt.TimeROIfilename = 'locROI_loc_main_lda_objWithWordOrSoundOrNoise_TFCEp05_1tail_maskedLoclizer.mat';
testopt.ManuallyMaskDiagonal = false; % if true, when testing diagonal include only timepoints in diagonalMask, otherwise will use TimeROIfilename as mask
testopt.diagonalMask = [zeros(1,14), ones(1,1), zeros(1,3), ones(1,2), zeros(1,32),ones(1,3),zeros(1,5)]; %timepoints to include in significance testing of diagonal
singleTailed = true; % if true, significance of permutation test (TFCE) is tested as one-tail (if false - 2-tailed).
% contrasts: defines contrasts for significance testing:
%   condition numbers corresponding to the conditions in condPairs that are to be tested, or in contrast to an absolute value of 0.5 (chance) 
% contrasts = struct('names',{'intactObj'},'cond1',{1},'cond2',{0.5}); % for intact-objects (localizer) against chance (with 1-tail)
contrasts = struct('names',{'objWithWord','objWithSounds','objWithNoise',... % for cross-decoding against chance (with 1-tail and intact-obj mask).
    'objWithClearSounds','grayWithSound',...
    'cond1',{1,2,3,4,5},'cond2',{0.5,0.5,0.5,0.5,0.5}); 
% contrasts = struct ('names',{'objWithWord-objWithNoise',... % for cross-decoding word/sound against noise (with 1-tail and main-exp mask) 
%     'objWithSounds-objWithNoise','objWithClearSounds-objWithNoise},...
%     'cond1',{1,2,4},'cond2',{3,3,3});
% contrasts = struct ('names',{'objWithWord-objWithSound','objWithWord-objWithClearSound'},... % for cross-decoding between word/sound conditions (with 2-tail and main-exp mask)
%     'cond1',{1,1},'cond2',{2,4});

%% Start routine

% prepare folders and add paths

datadir=[ProjectRootDir filesep 'data' filesep 'raw']; % path to raw data folder
outdir = [ProjectRootDir filesep 'data' filesep 'preproc']; % path to output preprocessed data folder
resdir = [ProjectRootDir filesep 'results']; % path to output results folder
maxdir = [ProjectRootDir filesep 'data' filesep 'maxfiltered']; % path to max-filtered data folder

addpath(genpath(FTdir)); % add FieldTrip path without subfolders
% cimec_init_ft; % ft_defaults; % sets fieldtrip defaults and adds relevant subfolders
addpath(cosmopath); % add CosmoMVPA path without subfolders
cosmo_set_path;% sets cosmo defaults and adds relevant subfolderscd(cosmopath);
addpath(genpath(bioinfo)); % add bioinfo path with subfolders

if ~exist(datadir) % if raw data folder doesn't exist
    error(['data folder ' datadir ' not found']); % abort and display error
end

if ~exist(outdir) % if preprocessed data folder doesn't exist
    display(['output folder ' outdir ' does not exist. Creating new.']);
    mkdir(outdir); % create output folder
end

% subjects and stimulus-subset indexing
load([pwd filesep 'subjects.mat']); % mat file in script folder includeing the variable "subjectsMat"
subjects = subjectsMat(1,:); % cell matrix with first row of subject names and second row of subject group (corresponding to stimulus subset)
groups = subjectsMat(2,:); % row in subjects corresponding to stimulus subset

%% Phase1 - read epochs and perform filtering

if job == 1 % if should perform phase 1
    
    if maxfilter
        filesuffix = '_tsss_trans';
        datadir = maxdir;
        display('loading max-filtered data, not raw');
    else
        filesuffix = '';
    end

    for ss = 1:length(subjects) % loop subjects
        for run = 1:length(runsuffix) % loop runs
            
            % Get full name to data file
            temp = dir([datadir filesep subjects{ss} '*' runsuffix{run} filesuffix '.fif']);
            rawfilename = temp.name;
            clear('temp');
            
            % Read epochs
            cfg                         = []; % init
            cfg.dataset = [datadir filesep rawfilename]; % dataset file to load
            cfg.trialdef.eventtype      = eventTypeLabel % event type
            cfg.trialdef.eventvalue     = 1:lastTrigVal; % trigger values to load
            cfg.trialdef.prestim        = prestim; % how many seconds before trigger to include in each epoch
            cfg.trialdef.poststim       = poststim; % how many seconds after trigger to include in each epoch
            cfg = ft_definetrial(cfg); % call FieldTrip function to read epochs
            
            
            % Filtering 
            if isHiPass
                cfg.hpfilter = 'yes'; % hi-pass filter, yes or no
                cfg.hpfreq = 1; % frequency for hi-pass filtering
                cfg.hpfilttype='firws'; % default 'but'
                cfg.hpfiltdir='onepass-minphase';
                cfg.hpfiltwintype='kaiser';
            else
                cfg.hpfilter = 'no';
            end
            if isLoPass
                cfg.lpfilter   = 'yes'; % low-pass filter, yes or no
                cfg.lpfreq     = 45; % frequency for low-pass filtering
                cfg.lpfilttype = 'but' % or 'firws'; % default 'but'
            else
                cfg.lpfilter   = 'no';
            end
            if isPadding
                cfg.padding = 10; % how many timepoints to add before and after epoch as baseline before filtering (to avoid weird artifact)
            end
            cfg.channel = {'MEG'};
            cfg.outputfile  = [outdir filesep subjects{ss} '_' runsuffix{run} '.mat']; % output path for files
            temp = ft_preprocessing(cfg); % call FieldTrip function to filter and output data   
            clear('temp','cfg');

        end
    end

end


%% Phase 2 - prepare trials for Cosmo MVPA

if job == 2 % if should perform phase 2
    
    sX=0; % init
    
    for ss = 1:length(subjects) % loop subjects
        
        display(['subject ' subjects{ss} ' - ' mat2str(ss) ' out of ' mat2str(length(subjects))]);
        
        sX=sX+1; % update
        
        %%% prepare trials of main experiment
        
        % loop and concatenate runs
        rr = 0;
        for run = main 
            rr = rr+1;
            % load all data
            load([outdir filesep subjects{ss} '_' runsuffix{run} '.mat']);
            %Resample the data to handle memory issues
            cfg=[];
            cfg.resamplefs=data_samplerate;
            cfg.detrend    = opt.detrend;
            cfg.demean     = opt.demean;
            rundata=ft_resampledata(cfg,data);
            %concatenate
            if rr==1
                rsdata = rundata;
                rundata.trialinfo(:,:) = run;
                trialsInRuns = rundata.trialinfo;
            elseif rr>1
                rsdata.trial = [rsdata.trial,rundata.trial];
                rsdata.time = [rsdata.time,rundata.time];
                rsdata.trialinfo = [rsdata.trialinfo;rundata.trialinfo];
                rundata.trialinfo(:,:) = run;
                trialsInRuns = [trialsInRuns;rundata.trialinfo];
            end
            clear('cfg','data','rundata');
        end
            
        % timelock and load to cosmo dataset
        cfg=[];
        cfg.keeptrials='yes';
        data_all_tl=ft_timelockanalysis(cfg,rsdata);
        ds_trials=cosmo_meeg_dataset(data_all_tl);
        ds_trials.sa.runs = trialsInRuns;
        clear('rsdata','data_all_tl','cfg','trialsInRuns');
        %Extract trials for main experiment
        for trial=1:length(ds_trials.sa.trialinfo(:,1))
            truecond = false;
            for cond=1:size(condsMain,2)
                includeTrials = condsMain(cond).from:condsMain(cond).to;
                if any(ds_trials.sa.trialinfo(trial,1)==includeTrials)
                    ds_trials.sa.targets(trial,1)=cond;
                    ds_trials.sa.labels(trial,1)={condsMain(cond).title};
                    truecond = true;
                end
            end
            if ~truecond
                ds_trials.sa.targets(trial,1)=99;
                ds_trials.sa.labels(trial,1)={'oddball'};
            end
        end
        
        % save main experiment dataset
        save([outdir filesep subjects{ss} '_Trials_mainExp_' suffixString '.mat'],'ds_trials','condsMain','opt');
        clear('ds_trials');
        
        %%% prepare trials of localizer
        
        % loop and concatenate runs
        rr = 0;
        for run = loc 
            rr = rr+1;
            % load all data
            load([outdir filesep subjects{ss} '_' runsuffix{run} '.mat']);
            %Resample the data to handle memory issues
            cfg=[];
            cfg.resamplefs=data_samplerate;
            cfg.detrend    = opt.detrend;
            cfg.demean     = opt.demean;
            rundata=ft_resampledata(cfg,data);
            %concatenate
            if rr==1
                rsdata = rundata;
                rundata.trialinfo(:,:) = run;
                trialsInRuns = rundata.trialinfo;
            elseif rr>1
                rsdata.trial = [rsdata.trial,rundata.trial];
                rsdata.time = [rsdata.time,rundata.time];
                rsdata.trialinfo = [rsdata.trialinfo;rundata.trialinfo];
                rundata.trialinfo(:,:) = run;
                trialsInRuns = [trialsInRuns;rundata.trialinfo];
            end
            clear('cfg','data','rundata');
        end
            
        % timelock and load to cosmo dataset
        cfg=[];
        cfg.keeptrials='yes';
        data_all_tl=ft_timelockanalysis(cfg,rsdata);
        ds_trials=cosmo_meeg_dataset(data_all_tl);
        ds_trials.sa.runs = trialsInRuns;
        clear('rsdata','data_all_tl','cfg','trialsInRuns');
        %Extract trials for localizer
        for trial=1:length(ds_trials.sa.trialinfo(:,1))
            truecond = false;
            for cond=1:size(condsLoc,2)
                includeTrials = condsLoc(cond).from:condsLoc(cond).to;
                if any(ds_trials.sa.trialinfo(trial,1)==includeTrials)
                    ds_trials.sa.targets(trial,1)=cond;
                    ds_trials.sa.labels(trial,1)={condsLoc(cond).title};
                    truecond = true;
                end
            end
            if ~truecond
                ds_trials.sa.targets(trial,1)=99;
                ds_trials.sa.labels(trial,1)={'oddball'};
            end
        end
        
        % save localizer dataset
        save([outdir filesep subjects{ss} '_Trials_pattLoc_' suffixString '.mat'],'ds_trials','condsLoc','opt');
        clear('ds_trials');
        
    end
    
end

%% Phase 3 - timeXtime MVPA using Cosmo

if job == 3 % if should perform phase 3
    
    switch mvopt.d_channels
        case 0
            chantype = 'all_combined';
        case 1
            chantype = 'meg_axial';
        case 2
            chantype = 'meg_combined_from_planar';
    end
    
    
    for ss = 1:length(subjects) % loop subjects
        
        disp(['subject ' subjects{ss}]);
                           
        %%% prepare data %%%
        
        % load train data 
        if strcmp(mvopt.trainOn,'loc')
            load([outdir filesep subjects{ss} '_Trials_pattLoc_' suffixString '.mat']);
            condsTrain = condsLoc;
        elseif strcmp(mvopt.trainOn,'main')
            load([outdir filesep subjects{ss} '_Trials_mainExp_' suffixString '.mat']);
            condsTrain = condsMain;
        end
        ds_train=ds_trials; % include all runs
        clear('ds_trials');
        
        % load test data
        if strcmp(mvopt.testOn,'loc')
            load([outdir filesep subjects{ss} '_Trials_pattLoc_' suffixString '.mat']);
            condsTest = condsLoc;
        elseif strcmp(mvopt.testOn,'main')
            load([outdir filesep subjects{ss} '_Trials_mainExp_' suffixString '.mat']);
            condsTest = condsMain;
        end
        ds_test = ds_trials; % include all runs
        clear('ds_trials');

        % average across trials of same trigger value
        ds_train = cosmo_fx(ds_train, @(x)mean(x,1), 'trialinfo',1);
        ds_test = cosmo_fx(ds_test, @(x)mean(x,1), 'trialinfo',1);
        
        % assign chunk 1 for training, chunk 2 for testing
        ds_train.sa.chunks(1:size(ds_train.samples,1),1)=1;
        ds_test.sa.chunks(1:size(ds_test.samples,1),1)=2;
                
        % merge data
        ds_all=cosmo_stack({ds_train,ds_test},1);
        clear('ds_train','ds_test');
        
        % select channel types and coverage
        if mvopt.d_channels>0 % create channel type masks
            chantypes=cosmo_meeg_chantype(ds_all);
            chan_indices=find(cosmo_match(chantypes,'meg_axial'));
            axial_msk=cosmo_match(ds_all.fa.chan,chan_indices);
            chan_indices=find(cosmo_match(chantypes,'meg_planar'));
            planar_msk=cosmo_match(ds_all.fa.chan,chan_indices);
            clear('chan_indices')
        end
        if mvopt.ap_channels>0 % create anterior/posterior masks
            anterior_msk=cosmo_match(ds_all.fa.chan,[1:163]);
            posterior_msk = cosmo_match(ds_all.fa.chan,[164:306]);
        end
        if (mvopt.d_channels == 0) && (mvopt.ap_channels == 0) % slice by masks
        elseif (mvopt.d_channels == 0) && (mvopt.ap_channels == 1)
            ds_all = cosmo_dim_slice(ds_all,anterior_msk,2);
        elseif (mvopt.d_channels == 0) && (mvopt.ap_channels == 2)
            ds_all = cosmo_dim_slice(ds_all,posterior_msk,2);
        elseif (mvopt.d_channels == 1) && (mvopt.ap_channels == 0)
            ds_all = cosmo_dim_slice(ds_all,axial_msk,2);
        elseif (mvopt.d_channels == 1) && (mvopt.ap_channels == 1)
            cmb_msk = intersect(find(axial_msk),find(anterior_msk));
            ds_all = cosmo_dim_slice(ds_all,cmb_msk,2);
        elseif (mvopt.d_channels == 1) && (mvopt.ap_channels == 2)
            cmb_msk = intersect(find(axial_msk),find(posterior_msk));
            ds_all = cosmo_dim_slice(ds_all,cmb_msk,2);
        elseif (mvopt.d_channels == 2) && (mvopt.ap_channels == 0)
            ds_all = cosmo_dim_slice(ds_all,planar_msk,2);
        elseif (mvopt.d_channels == 2) && (mvopt.ap_channels == 1)
            cmb_msk = intersect(find(planar_msk),find(anterior_msk));
            ds_all = cosmo_dim_slice(ds_all,cmb_msk,2);
        elseif (mvopt.d_channels == 2) && (mvopt.ap_channels == 2)
            cmb_msk = intersect(find(planar_msk),find(posterior_msk));
            ds_all = cosmo_dim_slice(ds_all,cmb_msk,2);
        end
        
        % remove NaN channels
        ds_all = cosmo_remove_useless_data(ds_all, 1, 'finite'); % removes nonfinite (Nan/infinite) features (hopefully channels not timepoints)

        % select timepoints to analyze
        timewindow_msk=cosmo_match(ds_all.fa.time,includeTimepoints);
        ds_all = cosmo_dim_slice(ds_all,timewindow_msk,2);
        
        % temporal smoothing of signal data
        if mvopt.numNeighbAvg>0
            smoothed_samples = ds_all.samples;
            for tt = 1+mvopt.numNeighbAvg:length(includeTimepoints)-mvopt.numNeighbAvg;
                SumOfTp = ds_all.samples(:,(ds_all.fa.time==tt));
                for tp = 1:mvopt.numNeighbAvg
                    SumOfTp = SumOfTp +...
                        ds_all.samples(:,(ds_all.fa.time==(tt+tp))) +...
                        ds_all.samples(:,(ds_all.fa.time==(tt-tp)));
                end
                MeanOfTp = SumOfTp./((2*mvopt.numNeighbAvg)+1);
                smoothed_samples(:,(ds_all.fa.time==tt)) = MeanOfTp;
                clear('MeanOfTp','SumOfTp','tp');
            end
            ds_all.samples = smoothed_samples;
            clear('smoothed_samples','tt');
        end
                
        %%% prepare results vars %%%
        
        accuracy = cell(1,length(condPairs));
        for co = 1:length(condPairs) % loop classification pairs
            accuracy{1,co} = zeros(length(includeTimepoints),length(includeTimepoints));
        end
        sameTime = cell(1,length(condPairs));
        for co = 1:length(condPairs) % loop classification pairs
            sameTime{1,co} = zeros(1,length(includeTimepoints));
        end
        smoothedTime = cell(1,length(condPairs));
        for co = 1:length(condPairs) % loop classification pairs
            smoothedTime{1,co} = zeros(1,length(includeTimepoints));
        end
        
        %%% preform analysis %%%
        
        % loop classification pairs
        for co = 1:length(condPairs) 
            
            if testOnSpecificExemplars % testing predicitons only on predefined samples
                if ismember(co,withinWhichCondPair)
                    load([ProjectRootDir filesep 'scripts' filesep 'stimIndex.mat']);
                    currColumnData = stimIndex(:,stimIndexColumns{co}(groups{ss}));
                    currTrigsToInclude = [];
                    currTrigsToInclude = stimIndex(find(currColumnData),1);
                    clear('currColumnData','stimIndex');
                end
            end

            disp(['pair ' mat2str(co) ' of ' mat2str(length(condPairs))]);

            % get training data of classification pair
            chunk1_msk=cosmo_match(ds_all.sa.chunks,1);
            targets1train_msk = cosmo_match(ds_all.sa.targets,condPairs(co).class1train);
            cl1train_msk = intersect(find(chunk1_msk),find(targets1train_msk));
            ds_class1{1} = cosmo_dim_slice(ds_all,cl1train_msk,1);
            targets2train_msk = cosmo_match(ds_all.sa.targets,condPairs(co).class2train);
            cl2train_msk = intersect(find(chunk1_msk),find(targets2train_msk));
            ds_class2{1} = cosmo_dim_slice(ds_all,cl2train_msk,1);
            clear('chunk1_msk','targets1train_msk','cl1train_msk','targets2train_msk','cl2train_msk');

            % get testing data of classification pair
            chunk2_msk=cosmo_match(ds_all.sa.chunks,2);
            targets1test_msk = cosmo_match(ds_all.sa.targets,condPairs(co).class1test);
            cl1test_msk = intersect(find(chunk2_msk),find(targets1test_msk));
            ds_class1{2} = cosmo_dim_slice(ds_all,cl1test_msk,1);
            targets2test_msk = cosmo_match(ds_all.sa.targets,condPairs(co).class2test);
            cl2test_msk = intersect(find(chunk2_msk),find(targets2test_msk));
            ds_class2{2} = cosmo_dim_slice(ds_all,cl2test_msk,1);
            clear('chunk2_msk','targets1test_msk','cl1test_msk','targets2test_msk','cl2test_msk');
            
            % stack and assign class1 labels
            ds_class1_all = cosmo_stack(ds_class1,1); % stack
            ds_class1_all.sa.targets(:) = 1; % replace all cond numbers with the value "1"
            ds_class1_all.sa.labels = cell(length(ds_class1_all.sa.targets),1);
            ds_class1_all.sa.labels(:) = {[condPairs(co).names '_class1']}; % add target string labels

            % stack and assign class2 labels
            ds_class2_all = cosmo_stack(ds_class2,1); % stack
            ds_class2_all.sa.targets(:) = 2; % replace all cond numbers with the value "2"
            ds_class2_all.sa.labels = cell(length(ds_class2_all.sa.targets),1);
            ds_class2_all.sa.labels(:) = {[condPairs(co).names '_class2']}; % add target string labels

            ds_bothClasses = cosmo_stack({ds_class1_all,ds_class2_all},1); % stack classes into one cosmo dataset
            ds_pair = cosmo_split(ds_bothClasses,'chunks',1);
            clear('ds_class1','ds_class1_all','ds_class2','ds_class2_all','ds_bothClasses');
        
            % loop timepoints
            for t1=1:length(includeTimepoints)

                if ~rem(t1,10)*t1/10
                    disp(['timepoint ' mat2str(t1) ' of ' mat2str(length(includeTimepoints))]);
                end

                % get training data of timepoint
                t1_msk=cosmo_match(ds_pair{1}.fa.time,t1);
                ds_t{1} = cosmo_dim_slice(ds_pair{1},t1_msk,2);
                clear('t2_msk');

                for t2=1:length(includeTimepoints) 

                    % get testing data of timepoint
                    t2_msk=cosmo_match(ds_pair{2}.fa.time,t2);
                    ds_t{2} = cosmo_dim_slice(ds_pair{2},t2_msk,2);
                    ds_t{2}.a.fdim.values = ds_t{1}.a.fdim.values;
                    
                    ds_analyze = cosmo_stack(ds_t,1);
                    clear('t2_msk');
                    
                    % run classifier
                    cv_args.rawpartitions = cosmo_nchoosek_partitioner(ds_analyze,1,'chunks',2); % partition data assigning chunk 2 for testing
                    cv_args.partitions = cosmo_balance_partitions(cv_args.rawpartitions,ds_analyze); % balance number of samples in each class
                    if testOnSpecificExemplars % if testing predicitons only on specific samples
                        if ismember(co,withinWhichCondPair)
                            cv_args.output = 'winner_predictions'; % get predictions per sample (not averaged)
                        end
                    end
                    cv_args.classifier = @cosmo_classify_lda; % choose lda classifier used by Cosmo
                    acc = cosmo_crossvalidation_measure(ds_analyze,cv_args); % run cosmo crossvalidation on dataset
                    if testOnSpecificExemplars % if testing predicitons only on specific samples
                        if ismember(co,withinWhichCondPair)
                            newsamplematrix = [];
                            for smpl = 1:length(acc.sa.trialinfo)
                                if ~isnan(acc.samples(smpl))
                                    if ismember(acc.sa.trialinfo(smpl),currTrigsToInclude)
                                        if acc.samples(smpl) == acc.sa.targets(smpl)
                                            newsamplematrix = [newsamplematrix; 1];
                                        else
                                            newsamplematrix = [newsamplematrix; 0];
                                        end
                                    end
                                end
                            end
                            acc.samples = mean(newsamplematrix);
                            clear('newsamplematrix','smpl');
                        end
                    end
                    
                    accuracy{1,co}(t1,t2) = acc.samples; % assign value to subject matrix
                    mvopt.cv_args = cv_args;
                    clear('acc','cv_args');
                    
                    if t1==t2 % if comparing the same timepoint add to sameTime vector
                        sameTime{1,co}(t1) = accuracy{1,co}(t1,t2);
                    end
                    
                    clear('ds_analyze','ds_t{2}');

                end
                
                clear('ds_t');
                
            end
            
            clear('ds_pair');
        
        end
        
        %%% calculate and store results %%%
        
        % get smoothed accuracy - for each timepoint saves average accuracy
        %   across a square centered at t1 and its mvopt.numNeighbSmooth neighbours
        %   in the timeXtime matrix). e.g. for mvopt.numNeighbSmooth=1 --> 9 timepoint square
        for t1=1:length(includeTimepoints) % loop timepoints
            for co = 1:length(condPairs) % loop classification pairs
                if t1<mvopt.numNeighbSmooth+1 % first timepoints
                    smoothedTime{1,co}(t1) = ...
                        mean(mean(accuracy{1,co}(1:t1+mvopt.numNeighbSmooth,1:t1+mvopt.numNeighbSmooth)));
                elseif t1>length(includeTimepoints)-mvopt.numNeighbSmooth % last timepoints
                    smoothedTime{1,co}(t1) = ...
                        mean(mean(accuracy{1,co}(t1-mvopt.numNeighbSmooth:end,t1-mvopt.numNeighbSmooth:end)));
                else % all other timepoints
                    smoothedTime{1,co}(t1) = ...
                        mean(mean(accuracy{1,co}(t1-mvopt.numNeighbSmooth:t1+mvopt.numNeighbSmooth,...
                        t1-mvopt.numNeighbSmooth:t1+mvopt.numNeighbSmooth)));
                end
            end
        end            
                
        % update vars across subjects
        if ss==1 % init the across-subjects matrices
            accuracy_all = accuracy;
            sameTime_all = sameTime;
            sameTime_stack = sameTime;
            smoothedTime_all = smoothedTime;
            smoothedTime_stack = smoothedTime;
        else
            for co = 1:length(condPairs) % loop classification pairs
                accuracy_all{1,co} = accuracy_all{1,co} + accuracy{1,co};
                sameTime_all{1,co} = sameTime_all{1,co} + sameTime{1,co};
                sameTime_stack{1,co} = [sameTime_stack{1,co}; sameTime{1,co}];
                smoothedTime_all{1,co} = smoothedTime_all{1,co} + smoothedTime{1,co};
                smoothedTime_stack{1,co} = [smoothedTime_stack{1,co}; smoothedTime{1,co}];
            end
        end

        % save subject results
        save([resdir filesep subjects{ss} '_MVPA_' mvopt.trainOn '_' mvopt.testOn...
            '_lda_' resString '_' suffixString '.mat'],...
            'accuracy','sameTime','smoothedTime','condPairs','mvopt','opt'); 
        clear('accuracy','sameTime','smoothedTime','ds_all');
        
    end
    
    % divide the sum by number of subjects to get the average across subjects
    for co = 1:length(condPairs) % loop classification pairs
        accuracy_all{1,co} = accuracy_all{1,co} ./ length(subjects);
        sameTime_all{1,co} = sameTime_all{1,co} ./ length(subjects);
        smoothedTime_all{1,co} = smoothedTime_all{1,co} ./ length(subjects);
    end
    
    % save tallied results
    save([resdir filesep 'MVPA_' mvopt.trainOn '_' mvopt.testOn '_lda_' resString '_' suffixString '.mat'],...
        'accuracy_all','sameTime_all','sameTime_stack',...
        'smoothedTime_all','smoothedTime_stack','condPairs','mvopt','opt');
    clear('accuracy_all','sameTime_all','sameTime_stack','smoothedTime_all','smoothedTime_stack');

end


%% Phase4 - group significance test of timeXtime maps

if job == 4 % if should perform phase 4
    
    if testopt.maskWithTimeROI
        load([resdir filesep testopt.TimeROIfilename]);
        locROI=accuracy_all{1,1};
    end

    for cont = 1:length(contrasts)

        for ss = 1:length(subjects) % loop subjects
        
            % Load subject's results
            load([resdir filesep subjects{ss} '_MVPA_' mvopt.trainOn '_' mvopt.testOn,...
                '_lda_' resString '_' suffixString '.mat']);
            
            % get left side of contrast
            m1 = accuracy{1,contrasts(cont).cond1} - 0.5;
            diagSmooth1 = smoothedTime{1,contrasts(cont).cond1} - 0.5;
            diagSame1 = sameTime{1,contrasts(cont).cond1} - 0.5;
            
            % get right side of contrast
            if contrasts(cont).cond2==0.5 % if contrasting with absolute value
                m2 = 0;
                diagSmooth2 = 0;
                diagSame2 = 0;
            else % if contrasting with single condition
                m2 = accuracy{1,contrasts(cont).cond2} - 0.5;
                diagSmooth2 = smoothedTime{1,contrasts(cont).cond2} - 0.5;
                diagSame2 = sameTime{1,contrasts(cont).cond2} - 0.5;
            end
            
            % get contrast
            m = m1 - m2;
            diagSmooth = diagSmooth1 - diagSmooth2;
            diagSame = diagSame1 - diagSame2;
            clear('m1','m2','diagSmooth1','diagSmooth2');
 
            % mask with timeXtime ROI
            if testopt.maskWithTimeROI
                m(locROI<1)=nan; % mask matrix
                % mask diagonal
                if testopt.ManuallyMaskDiagonal % use manually defined mask
                    diagSmooth(testopt.diagonalMask<1)=nan;
                    diagSame(testopt.diagonalMask<1)=nan;
                else % get diagonal of matrix mask
                    for tt= 1:length(diagSmooth)
                        if locROI(tt,tt)==0
                            diagSmooth(tt)=nan;
                            diagSame(tt)=nan;
                        end
                    end
                end
            end
            
            % reshape for Cosmo dataset
            m_3d=reshape(m', [1 size(m)]);
            sz=size(m);
            ds{ss}=cosmo_flatten(m_3d, {'time1','time2'}, {1:sz(1),1:sz(2)});
            ds{ss}.sa.chunks=ss;
            ds{ss}.sa.targets=1;
            ds_diagSmooth{ss}=cosmo_flatten(diagSmooth, {'time1'}, {1:sz(1)});
            ds_diagSmooth{ss}.sa.chunks=ss;
            ds_diagSmooth{ss}.sa.targets=1;
            ds_diagSame{ss}=cosmo_flatten(diagSame, {'time1'}, {1:sz(1)});
            ds_diagSame{ss}.sa.chunks=ss;
            ds_diagSame{ss}.sa.targets=1;
            

        end
        
        % combine all subjects into one dataset
        ds_stack = cosmo_stack(ds,1);
        ds_diagSmooth_stack = cosmo_stack(ds_diagSmooth,1);
        ds_diagSame_stack = cosmo_stack(ds_diagSame,1);
        clear('ds','m','m_3d','ds_diagSmooth');
        
        % get global ROI average per subject
        ds_temp = cosmo_remove_useless_data(ds_stack);
        ROIavg = mean((ds_temp.samples+0.5),2);
        clear('ds_temp');

        % define neighbourhood for cosmo
        nb1=cosmo_interval_neighborhood(ds_stack,'time1','radius',1);
        nb2=cosmo_interval_neighborhood(ds_stack,'time2','radius',1);
        nb=cosmo_cross_neighborhood(ds_stack, {nb1, nb2});
        nb.a.fdim.values=cellfun(@(x)x',nb.a.fdim.values,'UniformOutput',false);
        nb_clust=cosmo_cluster_neighborhood(ds_stack,nb);
        clear('nb','nb1','nb2')
        % test
        args=cosmo_structjoin('niter',1000,...
            'cluster_stat','tfce','h0_mean',0);
        zs = cosmo_montecarlo_cluster_stat(ds_stack,nb_clust, args); % run clustering
        if singleTailed 
            ps = normcdf(zs.samples,'upper'); % one tailed
        else
            ps = 2*normcdf(-abs(zs.samples)); % two tailed
            ps(zs.samples<0)= -ps(zs.samples<0);
        end
        clear('nb_clust');
        % tidy data
        ps = vec2mat(ps,sz(1));
        zs = zs.samples;
        zs = vec2mat(zs,sz(1));

        % do the same for the smoothed diagonal timecourse
        nb=cosmo_interval_neighborhood(ds_diagSmooth_stack,'time1','radius',1);
        nb.a.fdim.values=cellfun(@(x)x',nb.a.fdim.values,'UniformOutput',false);
        nb_clust=cosmo_cluster_neighborhood(ds_diagSmooth_stack,nb);
        clear('nb','nb1','nb2')
        % test
        zs_diagSmooth = cosmo_montecarlo_cluster_stat(ds_diagSmooth_stack,nb_clust, args); % run clustering
        if singleTailed 
            ps_diagSmooth = normcdf(zs_diagSmooth.samples,'upper');
        else
            ps_diagSmooth = 2*normcdf(-abs(zs_diagSmooth.samples));
            ps_diagSmooth(zs_diagSmooth.samples<0)= -ps_diagSmooth(zs_diagSmooth.samples<0);
        end
        clear('nb_clust');
        % tidy data
        ps_diagSmooth = vec2mat(ps_diagSmooth,sz(1));
        zs_diagSmooth = zs_diagSmooth.samples;
        zs_diagSmooth = vec2mat(zs_diagSmooth,sz(1));

        % do the same for the unsmoothed diagonal timecourse
        nb=cosmo_interval_neighborhood(ds_diagSame_stack,'time1','radius',1);
        nb.a.fdim.values=cellfun(@(x)x',nb.a.fdim.values,'UniformOutput',false);
        nb_clust=cosmo_cluster_neighborhood(ds_diagSame_stack,nb);
        clear('nb','nb1','nb2')
        % test
        zs_diagSame = cosmo_montecarlo_cluster_stat(ds_diagSame_stack,nb_clust, args); % run clustering
        if singleTailed 
            ps_diagSame = normcdf(zs_diagSame.samples,'upper');
        else
            ps_diagSame = 2*normcdf(-abs(zs_diagSame.samples));
            ps_diagSame(zs_diagSame.samples<0)= -ps_diagSame(zs_diagSame.samples<0);
        end
        clear('nb_clust');
        % tidy data
        ps_diagSame = vec2mat(ps_diagSame,sz(1));
        zs_diagSame = zs_diagSame.samples;
        zs_diagSame = vec2mat(zs_diagSame,sz(1));

        % save
        save([resdir filesep 'MVPA_' mvopt.trainOn '_' mvopt.testOn...
            '_lda_' resString '_' suffixString...
            '_' contrasts(cont).names '.mat'],...
            'zs','ps','ds_stack','zs_diagSmooth','ps_diagSmooth','ds_diagSmooth_stack',...
            'zs_diagSame','ps_diagSame','ds_diagSame_stack',...
            'args','subjects','condPairs','mvopt','ROIavg','testopt');
        
        clear('zs','ps','ds_stack','zs_diagSmooth','ps_diagSmooth','ds_diagSmooth_stack',...
            'zs_diagSame','ps_diagSame','ds_diagSame_stack',...
            'args','nb_clust','ds','ROIavg');
        
    end
end


end